### Name: FMbw
### Title: Modified critical bandwidth
### Aliases: FMbw


### ** Examples

x <- rnorm(100,0,1)
FMbw(x,1)
FMbw(x,1,m0=0)



