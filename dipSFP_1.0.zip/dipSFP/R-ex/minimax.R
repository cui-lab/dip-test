### Name: minimax
### Title: Minimax function
### Aliases: minimax


### ** Examples

x <- rnorm(10,0,1)
minimax(cbind(seq(x),x))



