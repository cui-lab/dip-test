dipSFP <-
function(dat,nboot,lambda0=NULL,outliers.ratio=NULL,m0=NULL,pvalue=TRUE,tol=1e-6){
  smboot <- function(vec,k,nboot,lambda0=NULL,outliers.ratio=NULL,m0=NULL,tol=tol){
    hcrit <- FMbw(vec,k,lambda0,outliers.ratio,m0,tol)
    n <- length(vec)
    sigmasq <- var(vec)
    bsampling <- function(y){
      z <- sample(y,replace=TRUE)
      zbar <- mean(z)
      return(zbar+(z-zbar+hcrit*rnorm(n,0,1))/sqrt(1+hcrit^2/sigmasq))
    }
    return(sapply(1:nboot,function(i) bsampling(vec)))
  }
  stat <- apply(dat,1,dip)
  bstat <- apply(dat,1,function(x)
                 apply(smboot(x,k=1,nboot,lambda0,outliers.ratio,m0,tol),2,dip))
  dis.null <- as.vector(bstat)
  if (pvalue){
    pvals <- sapply(stat,function(x) mean(dis.null>x))
    padj <- p.adjust(pvals,method="BH")
    out <- list(dip.statistics=stat,
                null.distribution=dis.null,
                p.values=pvals,
                adjusted.pvalues=padj)
  }
  else{
    out <- list(dip.statistics=stat,
                null.distribution=dis.null)
  }
  return(out)
}

