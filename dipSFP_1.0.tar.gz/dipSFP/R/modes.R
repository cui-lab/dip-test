modes <-
function(vec,bw,lambda0=NULL,outliers.ratio=NULL,m0=NULL){
  if (is.null(lambda0))
      lambda0 <- 0
  if (is.null(outliers.ratio))
    outliers.ratio <- 0
  if (is.null(m0))
    m0 <- 0.003
  lambda0 <- max(lambda0,outliers.ratio/bw/sqrt(2*pi))
  dens <- density(vec,bw=bw)
  x <- dens$x
  y <- sign.plus(dens$y-lambda0)
  if (all(y==0))
    stop("lambda0 is too large!")
  intv <- range(x[which(y>0)])
  vec <- vec[which((vec>=intv[1])&(vec<=intv[2]))]
  dens <- density(vec,bw=bw)
  x <- dens$x
  y <- sign.plus(dens$y-lambda0)
  x <- c(x[1]-1e-16,x,x[length(x)]+1e-16)
  y <- c(0,y,0)
  index <- which(minimax(cbind(x,y))==-1)
  n.modes <- length(index)-1
  modes.dir <- sapply(1:n.modes,function(i) y[index[i]]<y[index[i+1]]) # true: combine with right, false: combine with left
  modes.dir[1] <- TRUE
  e <- sapply(1:n.modes,function(i)
              sign.plus(y[seq(index[i],index[i+1])]-max(y[index[i]],y[index[i+1]]))%*%c(diff(x[index[i]:index[i+1]]),0))
  while ((any(e<m0))&(n.modes>1)){
    minors <- c(which((e<m0)&(modes.dir==TRUE))+1,which((e<m0)&(modes.dir==FALSE)))
    index <- index[-minors]
    n.modes <- length(index)-1
    modes.dir <- sapply(1:n.modes,function(i) y[index[i]]<y[index[i+1]]) # true: combine with right, false: combine with left
    modes.dir[1] <- TRUE
    e <- sapply(1:n.modes,function(i)
                sign.plus(y[seq(index[i],index[i+1])]-max(y[index[i]],y[index[i+1]]))%*%c(diff(x[index[i]:index[i+1]]),0))
  }
  modes <- x[sapply(1:n.modes,function(i) seq(index[i],index[i+1])[which.max(y[seq(index[i],index[i+1])])])]
  return(modes)
}

