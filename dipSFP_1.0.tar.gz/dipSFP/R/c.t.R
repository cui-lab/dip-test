c.t <-
function(v){
  return(((gamma((v+1)/2)/gamma(v/2))^2/pi/(v+1))^(1/5))
}

