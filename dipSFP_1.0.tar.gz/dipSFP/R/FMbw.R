FMbw <-
function(vec,k,lambda0=NULL,outliers.ratio=NULL,m0=NULL,tol=1e-6){
  S <- function(vec,k,bw,lambda0,m0){
    dens <- density(vec,bw=bw)
    x <- dens$x
    y <- sign.plus(dens$y-lambda0)
    if (all(y==0))
      stop("lambda0 is too large!")
    intv <- range(x[which(y>0)])
    vec <- vec[which((vec>=intv[1])&(vec<=intv[2]))]
    dens <- density(vec,bw=bw)
    x <- dens$x
    y <- sign.plus(dens$y-lambda0)
    x <- c(x[1]-1e-16,x,x[length(x)]+1e-16)
    y <- c(0,y,0)
    index <- which(minimax(cbind(x,y))==-1)
    n.modes <- length(index)-1
    modes.dir <- sapply(1:n.modes,function(i) y[index[i]]<y[index[i+1]]) # true: combine with right, false: combine with left
    modes.dir[1] <- TRUE
    e <- sapply(1:n.modes,function(i)
                sign.plus(y[seq(index[i],index[i+1])]-max(y[index[i]],y[index[i+1]]))%*%c(diff(x[index[i]:index[i+1]]),0))
    while ((any(e<m0))&(n.modes>1)){
      minors <- c(which((e<m0)&(modes.dir==TRUE))+1,which((e<m0)&(modes.dir==FALSE)))
      index <- index[-minors]
      n.modes <- length(index)-1
      modes.dir <- sapply(1:n.modes,function(i) y[index[i]]<y[index[i+1]]) # true: combine with right, false: combine with left
      modes.dir[1] <- TRUE
      e <- sapply(1:n.modes,function(i)
                  sign.plus(y[seq(index[i],index[i+1])]-max(y[index[i]],y[index[i+1]]))%*%c(diff(x[index[i]:index[i+1]]),0))
    }
    s <- sum(sort(e,decreasing=TRUE)[-(1:k)])
    return(s)
  }
  if (min(vec)==max(vec)){
    return(0)
  }
  else{
    if (is.null(lambda0))
      lambda0 <- 0
    if (is.null(outliers.ratio))
      outliers.ratio <- 0
    if (is.null(m0))
      m0 <- 0.003
    hl <- max(vec)-min(vec)
    while (S(vec,k,hl,lambda0=max(lambda0,outliers.ratio/hl/sqrt(2*pi)),m0)==0){
      hl <- hl/2
    }
    hu <- hl*2
    while (hu-hl>tol){
      h <- (hu+hl)/2
      if (S(vec,k,h,lambda0=max(lambda0,outliers.ratio/h/sqrt(2*pi)),m0)==0)
        hu <- h
      else
        hl <- h
    }
    return(hu) # hu returned to guarantee there are k modes
  }
}

