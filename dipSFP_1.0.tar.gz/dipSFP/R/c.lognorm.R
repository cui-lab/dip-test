c.lognorm <-
function(mu,sigma){
  return((2*pi*exp(sigma^2))^(-1/5))
}

