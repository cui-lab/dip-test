minimax <-
function(func){ # func: list with two components x and y
  x <- func[,1]
  y <- func[,2]
  if (length(x)!=length(y))
    stop("The length of x and y in the density function should be the same!")
  diff1 <- sign(diff(y))
  out <- rep(NA,length(x))
  pos <- seq(x)
  pos.na <- which(diff1==0)
  if (length(pos.na)>0){
    pos <- pos[-pos.na]
    x <- x[-pos.na]
    y <- y[-pos.na]
    diff1 <- sign(diff(y))
  }
  n <- length(x)
  out.pos <- rep(0,n)
  out.pos[1] <- ifelse(diff1[1]==1,-1,1)
  out.pos[n] <- ifelse(diff1[n-1]==1,1,-1)
  out.pos[which(diff(diff1)==-2)+1] <- 1
  out.pos[which(diff(diff1)==2)+1] <- -1
  out[pos] <- out.pos
  while(any(is.na(out))){
    index <- which(is.na(out))
    out[index] <- out[index+1]
  }
  return(out)
}

