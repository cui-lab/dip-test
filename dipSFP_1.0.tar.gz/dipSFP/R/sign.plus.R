sign.plus <-
function(x){
  x[which(sign(x)==-1)] <- 0
  return(x)
}

