c.norm <-
function(mu,sigma){
  return((2*pi)^(-1/5))
}

