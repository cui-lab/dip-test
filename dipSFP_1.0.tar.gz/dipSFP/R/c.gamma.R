c.gamma <-
function(k,theta){
  return(((k-1)^(2*k-1)*exp(-2*(k-1))/gamma(k)^2)^(1/5))
}

